﻿using System;

namespace guessingGame
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Clear();
            GetAppInfo();

            Console.WriteLine("What is your name: ");

            string name = Console.ReadLine();

            Console.WriteLine("Hello {0}, lets play a game \n", name);


            while (true)
            {
                Random random = new Random();
                int number = random.Next(1, 10);
                int guess = 0;



                 

                Console.WriteLine("Guess a number between 1 and 10");

                while (guess != number)
                {
                    string input = Console.ReadLine();

                    if (!int.TryParse(input, out guess))
                    {
                        Console.ForegroundColor = ConsoleColor.Red;

                        Console.WriteLine("Error, please enter a number");

                        Console.ResetColor();

                        continue;
                    }


                    // Cast to int put is an guess 
                    guess = Int32.Parse(input);

                    // Match the numbers
                    if (guess != number)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;

                        Console.WriteLine("Wrong number please try again");

                        Console.ResetColor();
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("You guessed right, the correct number was {0}", guess);
                        Console.ResetColor();

                        Console.WriteLine("Would you like to play again [Y or N]");


                        while (true)
                        {
                            string answer = Console.ReadLine().ToUpper();

                            if (answer == "Y")
                            {
                                continue;
                            }
                            else if (answer == "N")
                            {
                                Console.ForegroundColor = ConsoleColor.Green;
                                Console.WriteLine("You have ended the program \n\n");
                                Console.ResetColor();
                                return;
                            }
                            else 
                            {
                                return;
                            }
                        }
                        

                       
                        

                    }
                }
            }
        }
            

        static void GetAppInfo()
        {
            string appName = "Number Guesser";
            string appVersion = "1.0";
            string appAuthor = "Nima J.Tamar";

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("{0}: Version{1} by {2}", appName, appVersion, appAuthor);
            Console.ResetColor();
        }
    }
}
