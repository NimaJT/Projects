﻿using System;

namespace RockPaperSicor
{
    class Program
    {
        static void Main(string[] args)
        {
            string userInpt, cpuInpt;
            string loop;
            int rndint;
            
            bool playAgain = true;

            while (playAgain)
            {

                int cpuScore = 0;
                int playerScore = 0;



                Console.Write("Choose between Rock, Paper, Scissors: ");
                userInpt = Console.ReadLine();

                Random rnd = new Random();
                rndint = rnd.Next(1, 4);

                while (playerScore < 3 && cpuScore < 3)
                {


                    switch (rndint)
                    {
                        case 1:
                            cpuInpt = "Rock";
                            Console.WriteLine("Computer chose Rock");
                            if (userInpt == "Rock")
                            {
                                Console.WriteLine("It is a Draw!!");
                            }
                            else if (userInpt == "Paper")
                            {
                                Console.WriteLine("You win!!");
                                playerScore++;
                            }
                            else if (userInpt == "Scissors")
                            {
                                Console.WriteLine("You Lose!!");
                                cpuScore++;
                            }
                            break;

                        case 2:
                            cpuInpt = "Scissors";
                            Console.WriteLine("Computer chose Scissors");
                            if (userInpt == "Rock")
                            {
                                Console.WriteLine("You Win!!");
                                playerScore++;
                            }
                            else if (userInpt == "Paper")
                            {
                                Console.WriteLine("You Lose!!");
                                cpuScore++;
                            }
                            else if (userInpt == "Scissors")
                            {
                                Console.WriteLine("It is a Draw!!");
                            }
                            break;
                        case 3:
                            cpuInpt = "Paper";
                            Console.WriteLine("Computer chose Paper");
                            if (userInpt == "Rock")
                            {
                                Console.WriteLine("You Lose!!");
                                cpuScore++;
                            }
                            else if (userInpt == "Paper")
                            {
                                Console.WriteLine("It is a Draw!!");
                            }
                            else if (userInpt == "Scissors")
                            {
                                Console.WriteLine("You Win!!");
                                playerScore++;
                            }
                            break;
                        default:
                            Console.WriteLine("Invalid entry");
                            break;
                    }

                    Console.WriteLine("\n\n Scores:\tPlayer:\t{0}\tCPU\t{1}",playerScore,cpuScore);
                }   

                if (playerScore == 3)
                {
                    Console.WriteLine("The Player has won");
                }
                else if (cpuScore == 3)
                {
                    Console.WriteLine("The computer has Won");
                }

                Console.WriteLine("Would you like to play again? y/n");
                loop = Console.ReadLine();

                if (loop == "y")
                {
                    playAgain = true;
                    Console.Clear();
                }
                else if(loop=="n")
                {
                    playAgain = false;
                }
                else
                {
                    Console.WriteLine("Invalid Entry");
                }


            }
        }
    }
}
