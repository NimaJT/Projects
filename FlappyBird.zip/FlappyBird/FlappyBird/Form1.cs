﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlappyBird
{
    public partial class Form1 : Form
    {

        int pipeSpeed = 8;
        int gravity = 5;
        int score = 0;


        public Form1()
        {
            InitializeComponent();
        }

        private void ground_Click(object sender, EventArgs e)
        {

        }

        private void gameTimerEvent(object sender, EventArgs e)
        {
            flappyBird.Top += gravity;
            bottomPipe.Left -= pipeSpeed;
            topPipe.Left -= pipeSpeed;
            scoreText.Text = "Score: " + score;

            if (bottomPipe.Left<-130) 
            {

                bottomPipe.Left = 800;
                score++;
            }
            if (topPipe.Left < -160)
            {

                topPipe.Left = 900;
                score++;
            }

            if(flappyBird.Bounds.IntersectsWith(bottomPipe.Bounds) ||
               flappyBird.Bounds.IntersectsWith(topPipe.Bounds) ||
               flappyBird.Bounds.IntersectsWith(ground.Bounds))
            {

                endGame();
            }

           
           
        }

        private void gameKeyisDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode==Keys.Up)
            {
                gravity = -5;
            }

        }

        private void gameKeyisUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Up)
            {
                gravity = 5;
            }
        }

        private void endGame()
        {
            gameTimer.Stop();
            scoreText.Text += "  Game Over!!!";
        }
    }
}
